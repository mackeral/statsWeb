<?php
class Structure {
    var $label;
    var $citationCount;
    var $downloadCount;
    function __construct(){
        $this->label = func_get_arg(0);
    }
    function getCitationCount(){ return $this->citationCount; }
    function setCitationCount(){ $this->citationCount = func_get_arg(0); }
    function addCitationCount(){ $this->citationCount += func_get_arg(0); }
    function getDownloadCount(){ return $this->downloadCount; }
    function setDownloadCount(){ $this->downloadCount = func_get_arg(0); }
    function addDownloadCount(){ $this->downloadCount += func_get_arg(0); }
}
?>