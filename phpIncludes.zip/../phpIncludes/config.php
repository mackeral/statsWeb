<?php
require_once('/home/mackeral/Web/phpIncludes/StatsPage.php');
require_once('/home/mackeral/Web/phpIncludes/HTMLLib.php');
require_once('/home/mackeral/Web/phpIncludes/Repository.php');
require_once('/home/mackeral/Web/phpIncludes/SetSpec.php');
require_once('/home/mackeral/Web/phpIncludes/Structure.php');
$dcIdentifiers = array('Berkeley Law Scholarship Repository'=>'http://scholarship.law.berkeley.edu');
$shortNames = array('Berkeley Law Scholarship Repository'=>'Berkeley Law');
$setSpecLabels = ['publication:bjesl'=>'Berkeley Journal of Entertainment & Sports Law', 'publication:californialawreview'=>'California Law Review', 'publication:facpubs'=>'Faculty Publications', 'publication:riesenfeld'=>'riesenfeld', 'publication:bjcl'=>'Berkeley Journal of Criminal Law', 'publication:bjil'=>'Berkeley Journal of International Law', 'publication:bjalp'=>'Berkeley Journal of African American Law & Policy', 'publication:books'=>'books', 'publication:clrcircuit'=>'clrcircuit', 'publication:aalj_gallery'=>'aalj_gallery', 'publication:aalj'=>'Asian American Law Journal'];
$request = HTMLLib::trimArray($_REQUEST);
?>