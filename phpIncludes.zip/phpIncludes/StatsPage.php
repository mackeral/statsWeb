<?php
class StatsPage	{
	private $styles;
	private $headScripts;
	private $footScripts;
	private $loadScripts;
	private $title;
	private $content;
	private $beforeWrapperContent;
	private $afterWrapperContent;

	public function __construct()	{ // title
		switch(func_num_args())	{
			case 1:
				$this->title = func_get_arg(0);
				break;			
			default:
				$this->title = 'Repository Statistics';
				break;
		}
		$this->styles = array();
		$this->headScripts = array();
		$this->footScripts = array();
		$this->loadScripts = array();
		$this->content = "";
	}
	
	public function addInternalCSS()	{
		if(func_num_args() > 0) $style = func_get_arg(0);
		if(func_num_args() > 1) $media = func_get_arg(1);
		if(func_num_args() > 2) $condition = func_get_arg(2);
		switch(func_num_args())	{
			case 1:	// style
				$this->styles[] = new CSSi(null, null, null, $style); break;
			case 2:	// style, media
				$this->styles[] = new CSSi(null, media, null, $style); break;
			case 3:	// style, media, condition
				$this->styles[] = new CSSi(null, $media, $condition, $style); break;
		}
	}	
	public function addExternalCSS()	{
		if(func_num_args() > 0) $url = func_get_arg(0);
		if(func_num_args() > 1) $media = func_get_arg(1);
		if(func_num_args() > 2) $condition = func_get_arg(2);
		switch(func_num_args())	{
			case 1:	// url
				$this->styles[] = new CSSi($url, null, null, null); break;
			case 2:	// url, media
				$this->styles[] = new CSSi($url, $media, null, null); break;
			case 3:	// url, media, condition
				$this->styles[] = new CSSi($url, $media, $condition, null); break;
		}
	}
	public function addScript()	{
		$script = func_get_arg(0);
		$when = (func_num_args() > 1) ? func_get_arg(1) : 'foot';
		switch($when)	{
			case 'head': $this->headScripts[] = $script; break;
			case 'load': $this->loadScripts[] = $script; break;
			default: $this->footScripts[] = $script; break;
		}
	}
	public function addComment($comment) { $this->content .= "\n<!-- $comment -->\n"; }
	public function addContent($content) { $this->content .= $content; }
	public function addAfterWrapperContent($content) { $this->afterWrapperContent .= $content; }
	public function addBeforeWrapperContent($content) { $this->beforeWrapperContent .= $content; }
	public function setTitle($title) { $this->title = $title; }
		
	public function __toString()	{
		$html = "<!DOCTYPE html>
<html lang='en'>
<head>
	<title>{$this->title}</title>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<meta name='description' content=''>
<meta name='author' content=''>
<link href='bootstrap/css/bootstrap.css' rel='stylesheet'>
<link href='css/stats.css' rel='stylesheet'>
<link href='css/bootstrap-sortable.css' rel='stylesheet'>
<link href='css/typeahead.js-bootstrap.css' rel='stylesheet'>";
		foreach($this->styles as $style) $html .= $style;
		foreach($this->headScripts as $headScript) $html .= $this->scriptToString($headScript);
		$html .= "</head>
<body>
";	
		if(!empty($this->beforeWrapperContent)) $html .= $this->beforeWrapperContent;
		$html .= '<div class="navbar navbar-inverse navbar-fixed-top">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="/stats/index.php">Repository Statistics</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav">
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Browse<b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="/stats/repositories.php">Repositories</a></li>
						<li><a href="/stats/institutionalAuthors.php">Institutional Authors</a></li>
						<li><a href="/stats/personalAuthors.php">Personal Authors</a></li>
						<li><a href="/stats/structures.php">Structures</a></li>
						<li><a href="/stats/types.php">Document Types</a></li>
					</ul>
				</li>
				<li><a href="/stats/about.php">About</a></li>
				<li><a href="/stats/contact.php">Contact</a></li>
			</ul>
			<p class="navbar-text pull-right"><a href="#">log in</a></p>
		</div>
	</div>
</div><div class="container">
	<div class="repoContainer">';
		$html .= HTMLLib::h(1, $this->title) . $this->content . '</div>';
		if(!empty($this->afterWrapperContent)) $html .= $this->afterWrapperContent;
		$html .= '</div></div><script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="js/bootstrap-sortable.js"></script>
<script src="js/typeahead.min.js"></script>
<script src="/stats/js/stats.js"></script>
';
		// add postload js
		foreach($this->footScripts as $footScripts) $html .= $this->scriptToString($footScripts);
		$html .= '<script>
$(function(){';
		foreach($this->loadScripts as $loadScript) { $html .= "
$loadScript
"; };
		$html .= '});
</script>';
		$html .= "
</body></html>";
		return $html;
	}
	private function scriptToString($script)	{
		if(preg_match('/^(http|\/).*/', $script)) return "<script src='$script'> </script>";
		else return "<script>\n$script </script>";
	}
}
class CSSi	{
	private $url;
	private $media;
	private $condition;
	private $styles;
	public function __construct($url, $media, $condition, $styles)	{
		$this->url = $url;
		$this->media = $media;
		$this->condition = $condition;
		$this->styles = $styles;
	}
	public function __toString()	{
		$attributes = array();
		if(isset($this->media)) $attributes['media'] = $this->media;
		if(isset($this->url))	{ // external
			$attributes['rel'] = 'stylesheet';
			$attributes['href'] = $this->url;
			$cssHTML = HTMLLib::element('link', null, $attributes);
		} else	{ // internal
			$cssHTML = HTMLLib::element('style', $this->styles, $attributes);
		}
		if(isset($this->condition) && (trim($this->condition) != '')) return "\r\n<!--[if {$this->condition}]>$cssHTML<![endif]-->\r\n";
		else return $cssHTML;
	}
}
?>
