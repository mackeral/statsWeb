<?php
require_once('/home/mackeral/Web/phpIncludes/StatsPage.php');
require_once('/home/mackeral/Web/phpIncludes/HTMLLib.php');
require_once('/home/mackeral/Web/phpIncludes/Repository.php');
require_once('/home/mackeral/Web/phpIncludes/SetSpec.php');
require_once('/home/mackeral/Web/phpIncludes/Structure.php');
$dcIdentifiers = array('Berkeley Law Scholarship Repository'=>'http://scholarship.law.berkeley.edu');
$shortNames = array('Berkeley Law Scholarship Repository'=>'Berkeley Law');
$setSpecLabels = ['publication:bjesl'=>'bjesl', 'publication:californialawreview'=>'California Law Review', 'publication:facpubs'=>'Faculty Publications', 'publication:riesenfeld'=>'riesenfeld', 'publication:bjcl'=>'bjcl', 'publication:bjil'=>'bjil', 'publication:bjalp'=>'bjalp', 'publication:books'=>'books', 'publication:clrcircuit'=>'clrcircuit', 'publication:aalj_gallery'=>'aalj_gallery', 'publication:aalj'=>'aalj'];
$request = HTMLLib::trimArray($_REQUEST);
?>