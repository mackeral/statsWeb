<?php
class HTMLLib	{
	public static function element()	{
		$tagName = func_get_arg(0);
		$content = func_get_arg(1);
		$attributes = (func_num_args()==3) ? func_get_arg(2) : null;
		$element = "<$tagName" . HTMLLib::churnAttributes($attributes);
		if((isset($content)) && (trim($content)!=''))	$element .= ">$content</$tagName>";
		else if(in_array($tagName, array('textarea','div','h2','p','script','thead','tfoot'))) $element .= "></$tagName>";
		else $element .= " />";
		return $element;
	}


	// convenenience methods
	public static function a()	{
		$linkText = func_get_arg(0);
		$href = func_get_arg(1);
		$attributes = (func_num_args() > 2) ? func_get_arg(2) : null;
		$attributes['href'] = $href;
		return HTMLLib::element('a', $linkText, $attributes);
	}
	public static function button()	{ // label[, id][, attributes][, type]
		$attributes = (func_num_args() > 2) ? func_get_arg(2) : array();
		$idArg = (func_num_args() > 1) ? func_get_arg(1) : null;
		if((!isset($attributes['id'])) && (!is_null($idArg))) $attributes['id'] = $idArg;
		if(func_num_args() > 3) {
			if(!is_null(func_get_arg(0))) $attributes['value'] = func_get_arg(0);
			$attributes['type'] = func_get_arg(3);
			$name = isset($attributes['name']) ? $attributes['name'] : $attributes['id'];
			return HTMLLib::input($name, $attributes);
		} else return HTMLLib::element('button', func_get_arg(0), $attributes);
	}
	public static function comment(){
		$content = func_get_arg(0);
		return "<!-- $content -->";
	}
	public static function div()	{
		$content = func_get_arg(0);
		$attributes = (func_num_args()==2) ? func_get_arg(1) : null;
		return HTMLLib::element('div', $content, $attributes);
	}
	public static function form()	{	// new Form(action, method, content[, attributes][, withUpload])
		$content = func_get_arg(2);
		$attributes = (func_num_args() > 3) ? func_get_arg(3) : array();
		$attributes['action'] = func_get_arg(0);
		$attributes['method'] = func_get_arg(1);
		if((func_num_args() > 4) && (func_get_arg(4)===true)) $attributes['enctype'] = 'multipart/form-data';
		return HTMLLib::element('form', $content, $attributes);
	}
	public static function h()	{
		$attributes = (func_num_args() > 2) ? func_get_arg(2) : null;
		return HTMLLib::element('h' . func_get_arg(0), func_get_arg(1), $attributes);
	}
	public static function img()	{
		$src = func_get_arg(0);
		$alt = func_get_arg(1);
		$attributesArg = (func_num_args() > 2) ? func_get_arg(2) : array();
		$attributes = array('src'=>$src, 'alt'=>$alt) + $attributesArg;
		return HTMLLib::element('img', null, $attributes);
	}
	public static function input()	{ // name[, attributes]
		$attributes = (func_num_args() > 1) ? func_get_arg(1) : null;
		if(!isset($attributes['name'])) $attributes['name'] = func_get_arg(0);
		return HTMLLib::element('input', null, $attributes);
	}
	public static function label()	{
		$for = func_get_arg(0);
		$text = func_get_arg(1);
		$attributes = (func_num_args() > 2) ? func_get_arg(2) : null;
		$attributes['for'] = $for;
		$attributes['id'] = "{$for}Label";
		return HTMLLib::element('label', $text, $attributes);
	}
	public static function li()	{
		$text = func_get_arg(0);
		$attributes = (func_num_args() > 1) ? func_get_arg(1) : null;
		return HTMLLib::element('li', $text, $attributes);
	}
	public static function ol()	{
		$listItems = func_get_arg(0);
		$attributes = (func_num_args() > 1) ? func_get_arg(1) : null;
		$quick = (func_num_args() > 2) ? func_get_arg(2) : true;
		$liHTML = '';
		if($quick === true) foreach($listItems as $listItem) $liHTML .= HTMLLib::li($listItem);
		else foreach($listItems as $listItem) $liHTML .= $listItem;
		return HTMLLib::element('ol', $liHTML, $attributes);
	}
	public static function p()	{
		$content = func_get_arg(0);
		$attributes = (func_num_args()==2) ? func_get_arg(1) : null;
		return HTMLLib::element('p', $content, $attributes);
	}
	public static function select()	{ // name, options[, attributes]
		$name = func_get_arg(0);
		$options = func_get_arg(1);
		$attributes = (func_num_args() > 2) ? func_get_arg(2) : array();
		$optionsHTML = '';
		foreach($options as $optionValue=>$optionLabel)	{
			$optionsHTML .= "<option value='$optionValue'";
			if((string)$optionValue==(string)$attributes['value']) $optionsHTML .= ' selected';
			$optionsHTML .= ">$optionLabel</option>";
		}
		$attributes['name'] = $name;
		unset($attributes['value']);
		if(!(isset($attributes['id']))) $attributes['id'] = $name;
		return HTMLLib::element('select', $optionsHTML, $attributes);
	}
	public static function span()	{
		$content = func_get_arg(0);
		$attributes = (func_num_args()==2) ? func_get_arg(1) : null;
		return HTMLLib::element('span', $content, $attributes);
	}
	public function strong()	{
		$content = func_get_arg(0);
		$attributes = (func_num_args() > 1) ? func_get_arg(1) : null;
		return HTMLLib::element('strong', $content, $attributes);
	}
	public static function table()	{ // tbody trs, table attributes, thead tr, tfoot tr
		$trs = func_get_arg(0);
		$attributes = (func_num_args() > 1) ? func_get_arg(1) : null;
		$headTR = (func_num_args() > 2) ? func_get_arg(2) : '';
		$tableHTML = HTMLLib::element('thead', $headTR);
		foreach($trs as $tr) $tbodyHTML .= $tr;
		$tableHTML .= HTMLLib::element('tbody', $tbodyHTML);
		if(func_num_args() > 3) $tableHTML .= HTMLLib::element('tfoot', func_get_arg(3));
		return HTMLLib::element('table', $tableHTML, $attributes);
	}
	public static function td()	{ // cell data[, attributes][, header]
		$content = func_get_arg(0);
		$attributes = (func_num_args() > 1) ? func_get_arg(1) : null;
		if((func_num_args() > 2) && (func_get_arg(2)===true)) return HTMLLib::element('th', $content, $attributes);
		return HTMLLib::element('td', $content, $attributes);
	}
	/*	// USE td($content, $attributes, true) instead so we can put ths in a thead tr
	public static function th()	{
		$content = func_get_arg(0);
		$attributes = (func_num_args() > 1) ? func_get_arg(1) : null;
		return HTMLLib::element('th', $content, $attributes);
	}
	*/
	public static function tr()	{	// td array[, quick][, attributes][, isHeader]
		$tds = func_get_arg(0);
		$quick = (func_num_args() > 1) ? func_get_arg(1) : true;
		$attributes = (func_num_args() > 2) ? func_get_arg(2) : null;
		$isHeader = (func_num_args() > 3) ? func_get_arg(3) : false;
		if($quick===true) foreach($tds as $td) $tdsHTML .= HTMLLib::td($td, null, $isHeader);
		else foreach($tds as $td) $tdsHTML .= $td;
		return HTMLLib::element('tr', $tdsHTML, $attributes);
	}
	public static function ul()	{	// li array [, attributes, quick]
		$listItems = func_get_arg(0);
		$attributes = (func_num_args() > 1) ? func_get_arg(1) : null;
		$quick = (func_num_args() > 2) ? func_get_arg(2) : true;
		$liHTML = '';
		if($quick === true) foreach($listItems as $listItem) $liHTML .= HTMLLib::li($listItem);
		else foreach($listItems as $listItem) $liHTML .= $listItem;
		return HTMLLib::element('ul', $liHTML, $attributes);
	}

/*
	function comment()	{
		$comment = func_get_arg(0);
		return "<!-- $comment -->";
	}
	function ol()	{
		$listItems = func_get_arg(0);
		$attributes = (func_num_args()==2) ? func_get_arg(1) : null;
		$liHTML = '';
		foreach($listItems as $listItem) $liHTML .= HTMLLib::element('li', $listItem);
		return HTMLLib::element('ol', $liHTML, $attributes);
	}
	function script()	{
		$content = func_get_arg(0);
		$attributes = (func_num_args()==2) ? func_get_arg(1) : array();
		$attributes['type'] = 'text/javascript';
		return HTMLLib::element('script', $content, $attributes);
	}
	*/
	
	// utility functions
	public static function churnAttributes($attributes)	{
		$attributeText = '';
		if(isset($attributes))	{
			foreach($attributes as $key=>$value)	{
				if($key==$value) $attributeText .= " $key";
				else $attributeText .= " $key=\"" . HTMLLib::escapeAttribute($value) . "\"";
			}
		}
		return $attributeText;
	}
	public static function escapeAttribute($rawText)	{
		return str_replace('"', '&quot;', $rawText);
	}
	/*
	function churnBreadCrumbs($breadCrumbs, $separator)	{
		$breadCrumbHTML = '';
		foreach($breadCrumbs as $url=>$text)	{
			$breadCrumbHTML .= HTMLLib::element('a', $text, array('href'=>$url)) . $separator;
		}
		return HTMLLib::element('div', $breadCrumbHTML, array('id'=>'breadCrumbs'));
	}
	function redDotJS($rawString)	{
		return str_replace("'", "\'", $rawString);
	}
*/
	public static function trimArray($rawArray)	{
		if(isset($rawArray) && (count($rawArray) != 0))	{
			$trimmedArray = array();
			foreach($rawArray as $rawKey=>$rawValue) $trimmedArray[trim($rawKey)] = trim($rawValue);
			return $trimmedArray;
		} else return null;
	}
	public static function dumpArray($array){
		$arrayString = '';
		foreach($array as $key=>$value)
			$arrayString . "[$key]=>[$value] ";
	}
}
?>