<?php
class Repository {
    var $label;
    var $identifierPrefix;
    var $citationCount;
    var $downloadCount;
    function __construct(){
        $this->label = func_get_arg(0);
    }
    function getCitationCount(){ return $this->citationCount; }
    function setCitationCount(){ $this->citationCount = func_get_arg(0); }
    function getDownloadCount(){ return $this->downloadCount; }
    function setDownloadCount(){ $this->downloadCount = func_get_arg(0); }
    function setIdentifierPrefix(){ $this->identifierPrefix = func_get_arg(0); }
}
?>